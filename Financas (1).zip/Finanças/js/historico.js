const lista = document.getElementById("listaMovimentacoes");

const pesquisa = document.getElementById("pesquisa");

const filtroBanco = document.getElementById("filtroBanco");

const filtroTipo = document.getElementById("filtroTipo");

// ---------------- BANCOS (para o filtro) ----------------

function carregarBancos() {

    let bancos = JSON.parse(localStorage.getItem("bancos"));

    if (bancos === null) {

        bancos = [
            { id: 1, nome: "Nubank", emoji: "🟣", cor: 0 },
            { id: 2, nome: "Inter", emoji: "🟠", cor: 1 },
            { id: 3, nome: "Mercado Pago", emoji: "⚫", cor: 2 },
            { id: 4, nome: "Dinheiro", emoji: "🟢", cor: 3 }
        ];

        localStorage.setItem("bancos", JSON.stringify(bancos));
    }

    return bancos;
}

function popularFiltroBanco() {

    const bancos = carregarBancos();

    bancos.forEach(item => {
        filtroBanco.innerHTML += `<option>${item.nome}</option>`;
    });
}

popularFiltroBanco();

let movimentacoes =
    JSON.parse(localStorage.getItem("movimentacoes")) || [];

function formatarMoeda(valor){

    return valor.toLocaleString("pt-BR",{

        style:"currency",

        currency:"BRL"

    });

}

function carregarMovimentacoes(){

    lista.innerHTML = "";

    const textoPesquisa = pesquisa.value.toLowerCase();

    const bancoSelecionado = filtroBanco.value;

    const tipoSelecionado = filtroTipo.value;

    const resultado = movimentacoes.filter(mov =>{

        const descricao =
            (mov.descricao || "").toLowerCase();

        const categoria =
            (mov.categoria || "").toLowerCase();

        const pesquisaOk =

            descricao.includes(textoPesquisa) ||

            categoria.includes(textoPesquisa);

        const bancoOk =

            bancoSelecionado === "" ||

            mov.banco === bancoSelecionado;

        const tipoOk =

            tipoSelecionado === "" ||

            mov.tipo === tipoSelecionado;

        return pesquisaOk && bancoOk && tipoOk;

    });

    if(resultado.length === 0){

        lista.innerHTML =

        `<div class="vazio">

            <h2>Nenhuma movimentação encontrada.</h2>

            <p>Cadastre uma movimentação para começar.</p>

        </div>`;

        return;

    }

    resultado.sort((a,b)=>b.id-a.id);

    resultado.forEach(mov=>{

        let classe = "";

        let sinal = "";

        let textoNatureza = "";

        if(mov.tipo==="Entrada"){

            classe="entrada";

            sinal="+";

            textoNatureza="Entrada";

        }

        else if(mov.natureza==="Despesa"){

            classe="despesa";

            sinal="-";

            textoNatureza="Despesa";

        }

        else if(mov.natureza==="Reserva"){

            classe="reserva";

            sinal="🏦";

            textoNatureza="Reserva";

        }

        else{

            classe="investimento";

            sinal="📈";

            textoNatureza="Investimento";

        }

        const card = document.createElement("div");

        card.className="movimentacao";

        card.innerHTML=`

            <div class="info">

                <h3>${mov.categoria}</h3>

                <p>${mov.descricao || "Sem descrição"}</p>

                <p>${mov.banco}</p>

                <p>${mov.data}</p>

                <p>${textoNatureza}</p>

            </div>

            <div class="valor ${classe}">

                ${sinal} ${formatarMoeda(mov.valor)}

            </div>

        `;

        lista.appendChild(card);

    });

}

pesquisa.addEventListener("input",carregarMovimentacoes);

filtroBanco.addEventListener("change",carregarMovimentacoes);

filtroTipo.addEventListener("change",carregarMovimentacoes);

document
.getElementById("voltarDashboard")
.addEventListener("click",()=>{

    window.location.href="dashboard.html";

});

carregarMovimentacoes();