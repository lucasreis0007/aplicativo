const movimentacoes =
    JSON.parse(localStorage.getItem("movimentacoes")) || [];

let saldoDisponivel = 0;
let patrimonioTotal = 0;

let entradas = 0;
let despesas = 0;
let reservas = 0;
let investimentos = 0;

movimentacoes.forEach((mov) => {

    if (mov.tipo === "Entrada") {

        entradas += mov.valor;

        saldoDisponivel += mov.valor;

    } else {

        switch (mov.natureza) {

            case "Despesa":
                despesas += mov.valor;
                saldoDisponivel -= mov.valor;
                break;

            case "Reserva":
                reservas += mov.valor;
                saldoDisponivel -= mov.valor;
                break;

            case "Investimento":
                investimentos += mov.valor;
                saldoDisponivel -= mov.valor;
                break;
        }

    }

});

patrimonioTotal =
    saldoDisponivel + reservas + investimentos;

function moeda(valor) {

    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });

}

document.getElementById("patrimonioTotal").textContent = moeda(patrimonioTotal);
document.getElementById("saldoDisponivel").textContent = moeda(saldoDisponivel);

document.getElementById("totalEntradas").textContent = moeda(entradas);
document.getElementById("totalDespesas").textContent = moeda(despesas);
document.getElementById("totalReservas").textContent = moeda(reservas);
document.getElementById("totalInvestimentos").textContent = moeda(investimentos);

// ---------------- CONTAS (BANCOS) ----------------

function carregarBancos() {

    let bancos = JSON.parse(localStorage.getItem("bancos"));

    if (bancos === null) {

        bancos = [
            { id: 1, nome: "Nubank", emoji: "🟣", cor: 0 },
            { id: 2, nome: "Inter", emoji: "🟠", cor: 1 },
            { id: 3, nome: "Mercado Pago", emoji: "⚫", cor: 2 },
            { id: 4, nome: "Dinheiro", emoji: "🟢", cor: 3 }
        ];

        localStorage.setItem("bancos", JSON.stringify(bancos));
    }

    return bancos;
}

function calcularSaldoBanco(nomeBanco) {

    let saldo = 0;

    movimentacoes.forEach(mov => {

        if (mov.banco !== nomeBanco) return;

        if (mov.tipo === "Entrada") {
            saldo += Number(mov.valor);
        } else {
            saldo -= Number(mov.valor);
        }

    });

    return saldo;
}

function renderizarContas() {

    const bancos = carregarBancos();
    const listaContas = document.getElementById("listaContas");

    listaContas.innerHTML = "";

    if (bancos.length === 0) {
        listaContas.innerHTML = `
            <div class="vazio">
                <h2>Nenhuma conta cadastrada.</h2>
                <p>Cadastre uma conta na página de Bancos.</p>
            </div>
        `;
        return;
    }

    bancos.forEach(banco => {

        const saldo = calcularSaldoBanco(banco.nome);

        const card = document.createElement("div");
        card.className = `conta cor-${banco.cor}`;

        card.innerHTML = `
            <div>
                <h3>${banco.emoji} ${banco.nome}</h3>
                <p>Saldo disponível</p>
            </div>
            <strong>${moeda(saldo)}</strong>
        `;

        listaContas.appendChild(card);
    });
}

renderizarContas();

// ---------------- METAS ----------------

function carregarMetas() {

    let metas = JSON.parse(localStorage.getItem("metas"));

    if (metas === null) {

        metas = [
            {
                id: 1,
                emoji: "🚗",
                nome: "CNH",
                valorObjetivo: 3000,
                valorAtual: 0
            },
            {
                id: 2,
                emoji: "🛡️",
                nome: "Reserva",
                valorObjetivo: 5000,
                valorAtual: 0
            }
        ];

        localStorage.setItem("metas", JSON.stringify(metas));
    }

    return metas;
}

function renderizarMetasDashboard() {

    const metas = carregarMetas();
    const listaMetasDash = document.getElementById("listaMetasDash");

    listaMetasDash.innerHTML = "";

    if (metas.length === 0) {
        listaMetasDash.innerHTML = `
            <div class="vazio">
                <h2>Nenhuma meta cadastrada.</h2>
                <p>Crie uma meta na página de Metas.</p>
            </div>
        `;
        return;
    }

    metas.forEach(meta => {

        const percentual = meta.valorObjetivo > 0
            ? Math.min(100, (meta.valorAtual / meta.valorObjetivo) * 100)
            : 0;

        const card = document.createElement("div");
        card.className = "meta";

        card.innerHTML = `
            <div class="meta-topo">
                <span>${meta.emoji} ${meta.nome}</span>
                <span>${percentual.toFixed(0)}%</span>
            </div>
            <div class="barra">
                <div class="progresso" style="width:${percentual}%"></div>
            </div>
        `;

        listaMetasDash.appendChild(card);
    });
}

renderizarMetasDashboard();

// ---------------- BOTÃO NOVA MOVIMENTAÇÃO ----------------

const botao = document.getElementById("novaMovimentacao");

if (botao) {

    botao.addEventListener("click", () => {

        window.location.href = "adicionar.html";

    });

}
